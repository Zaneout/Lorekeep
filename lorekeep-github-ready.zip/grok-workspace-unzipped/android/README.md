# Lorekeep Android APK

This Android wrapper loads the deployed Lorekeep web app in a native WebView.

1. Deploy the web app first so `/api/story` and `/api/memory` remain available.
2. Replace `android/app/src/main/res/values/strings.xml` `app_url` with that HTTPS deployment URL.
3. Open `android/` in Android Studio and build **Build > Generate App Bundles or APKs > Generate APKs**.

The source workspace already includes the PWA install flow. The wrapper is intentionally URL-based because the AI endpoints are server-side and cannot run from a static APK alone.
