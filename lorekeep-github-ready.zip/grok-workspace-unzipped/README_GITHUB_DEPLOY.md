# Lorekeep — GitHub + Vercel deployment

This package is prepared for uploading to a GitHub repository and deploying the web app with Vercel.

## Phone-only setup

1. Create a new **empty GitHub repository** (for example `lorekeep`). Do not add a README, .gitignore, or license during repository creation.
2. On the repository page, tap **Add file → Upload files**.
3. Upload the files and folders from this package. GitHub must receive the project files themselves; do not upload this ZIP as a single file.
4. Commit the upload to the `main` branch.
5. Open Vercel in your phone browser: https://vercel.com/ and sign in with GitHub.
6. Choose **Add New → Project**, select the Lorekeep repository, and deploy it.
7. Vercel will give you a public URL similar to `https://lorekeep-xxxx.vercel.app`.

## Important

The repository is already configured for a Vercel/Nitro deployment. No `.env` file is included.

If the app uses server-side AI/auth/database features, configure the required environment variables in Vercel's Project Settings before using those features. The app has a local PGLite fallback when `DATABASE_URL` is not supplied.

## After you get the Vercel URL

Open:

`android/app/src/main/res/values/strings.xml`

and replace the placeholder value for `app_url` with your Vercel URL:

`https://YOUR-DEPLOYED-LOREKEEP-URL.example`

Commit that change to GitHub. The included GitHub Actions workflow will then build the debug APK when the `android/` directory changes. The APK can be downloaded from the workflow run's **Artifacts** section.

## Do not upload secrets

Never put GitHub passwords, access tokens, API keys, OAuth secrets, database passwords, or `.env` files in this repository. Put secrets in Vercel/GitHub Secrets instead.
