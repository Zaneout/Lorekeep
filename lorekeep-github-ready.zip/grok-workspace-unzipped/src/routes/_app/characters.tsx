import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { CharacterAvatar } from "@/components/character-avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLore } from "@/lib/store";

export const Route = createFileRoute("/_app/characters")({
  component: CharactersPage,
});

function CharactersPage() {
  const characters = useLore((s) => s.characters);
  const createCharacter = useLore((s) => s.createCharacter);
  const stories = useLore((s) => s.stories);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = [...characters].sort((a, b) => a.name.localeCompare(b.name));
    if (!q) return list;
    return list.filter((c) =>
      `${c.name} ${c.role} ${c.aliases} ${c.tags.join(" ")} ${c.personality}`.toLowerCase().includes(q),
    );
  }, [characters, query]);

  async function onNew() {
    const character = await createCharacter({ name: "New character" });
    // Stay on the cast page after creation; the user can open the profile explicitly.
  }

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col px-4 pt-6 pb-8 md:px-8 md:pt-10">
      <header className="flex flex-col gap-6">
        <div>
          <p className="text-xs font-medium tracking-[0.14em] text-mute uppercase">Cast</p>
          <h1 className="mt-2 font-display text-3xl font-medium tracking-tight md:text-4xl">Character profiles</h1>
          <p className="mt-2 max-w-xl text-sm text-mute md:text-base">
            A dossier for everyone in your fiction. What you write here is injected into every story they enter.
          </p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative sm:max-w-sm sm:flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search the cast"
              className="pl-9"
            />
          </div>
          <Button className="sm:ml-auto" onClick={() => void onNew()}>
            <Plus className="size-4" />
            New character
          </Button>
        </div>
      </header>

      {filtered.length === 0 ? (
        <div className="mt-16">
          <p className="font-display text-2xl">No one on the page yet.</p>
          <p className="mt-2 max-w-md text-sm text-mute">
            Create a profile and the writer will keep their face, voice, and secrets straight across every chat.
          </p>
        </div>
      ) : (
        <ul className="mt-8 grid gap-3 sm:grid-cols-2">
          {filtered.map((character) => {
            const used = stories.filter((s) => s.characterIds.includes(character.id)).length;
            return (
              <li key={character.id}>
                <Link
                  to="/characters/$id"
                  params={{ id: character.id }}
                  className="flex h-full gap-4 rounded-xl bg-panel p-4 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_8%,transparent)] transition-[box-shadow] duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_16%,transparent)]"
                >
                  <CharacterAvatar name={character.name} mark={character.mark} size="lg" />
                  <div className="min-w-0 flex-1">
                    <h2 className="truncate font-display text-lg font-medium tracking-tight">
                      {character.name || "Unnamed"}
                    </h2>
                    <p className="mt-0.5 truncate text-sm text-mute">{character.role || "No role yet"}</p>
                    <p className="mt-2 line-clamp-2 text-sm text-faint">
                      {character.personality || character.appearance || "Open the profile to fill in the dossier."}
                    </p>
                    <p className="mt-3 text-xs text-faint tabular-nums">
                      {used === 0 ? "Not in a story yet" : used === 1 ? "In 1 story" : `In ${used} stories`}
                    </p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </main>
  );
}
