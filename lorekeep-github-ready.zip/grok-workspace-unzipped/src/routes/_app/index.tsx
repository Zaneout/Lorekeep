import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, MoreHorizontal, Plus, Upload } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { NewStoryDialog } from "@/components/new-story-dialog";
import { CharacterAvatar } from "@/components/character-avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import type { Character, LoreDump } from "@/lib/types";
import { useLore } from "@/lib/store";
import { relativeTime } from "@/lib/utils";

export const Route = createFileRoute("/_app/")({
  component: LibraryPage,
});

function LibraryPage() {
  const stories = useLore((s) => s.stories);
  const characters = useLore((s) => s.characters);
  const exportAll = useLore((s) => s.exportAll);
  const importAll = useLore((s) => s.importAll);
  const fileRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = [...stories].sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return b.lastMessageAt - a.lastMessageAt;
    });
    if (!q) return list;
    return list.filter((s) => {
      const cast = s.characterIds
        .map((id) => characters.find((c) => c.id === id)?.name ?? "")
        .join(" ");
      return `${s.title} ${s.premise} ${s.genre} ${s.tone} ${cast}`.toLowerCase().includes(q);
    });
  }, [stories, characters, query]);

  async function onExport() {
    const dump = await exportAll();
    const blob = new Blob([JSON.stringify(dump, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `lorekeep-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast("Archive downloaded");
  }

  async function onImport(file: File) {
    try {
      const dump = JSON.parse(await file.text()) as LoreDump;
      if ((dump.version !== 1 && dump.version !== 2) || !Array.isArray(dump.characters) || !Array.isArray(dump.stories)) {
        throw new Error("Unrecognized archive");
      }
      await importAll(dump);
      toast("Archive restored");
    } catch {
      toast.error("Could not read that archive");
    }
  }

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col px-4 pt-6 pb-8 md:px-8 md:pt-10">
      <header className="flex flex-col gap-6">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium tracking-[0.14em] text-mute uppercase">Library</p>
            <h1 className="mt-2 font-display text-3xl font-medium tracking-tight md:text-4xl">
              Stories without a ceiling
            </h1>
            <p className="mt-2 max-w-xl text-sm text-mute md:text-base">
              Unfiltered writing. Living memory that never resets. As many chats as you want — kept on this device.
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Library menu">
                  <MoreHorizontal className="size-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onSelect={() => void onExport()}>
                  <Download className="size-4" />
                  Export archive
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => fileRef.current?.click()}>
                  <Upload className="size-4" />
                  Import archive
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <a href="/?install=1">
                    <Download className="size-4" />
                    Install app
                  </a>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <input
              ref={fileRef}
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void onImport(file);
                e.target.value = "";
              }}
            />
          </div>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search stories"
            className="sm:max-w-sm"
          />
          <NewStoryDialog>
            <Button className="sm:ml-auto">
              <Plus className="size-4" />
              New story
            </Button>
          </NewStoryDialog>
        </div>
      </header>

      {filtered.length === 0 ? (
        <div className="mt-16 flex flex-1 flex-col items-start">
          <p className="font-display text-2xl text-ink">The desk is clear.</p>
          <p className="mt-2 max-w-md text-sm text-mute">
            Open a story and write without a filter. Cast stays in their profiles; memory stays in the thread.
          </p>
          <NewStoryDialog>
            <Button className="mt-6">
              <Plus className="size-4" />
              Begin
            </Button>
          </NewStoryDialog>
        </div>
      ) : (
        <ul className="mt-8 grid gap-3 sm:grid-cols-2">
          {filtered.map((story) => {
            const cast = story.characterIds
              .map((cid) => characters.find((c) => c.id === cid))
              .filter((c): c is Character => Boolean(c));
            return (
              <li key={story.id}>
                <Link
                  to="/story/$id"
                  params={{ id: story.id }}
                  className="flex h-full flex-col rounded-xl bg-panel p-4 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_8%,transparent)] transition-[box-shadow,transform] duration-150 hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_16%,transparent)]"
                >
                  <div className="flex items-start justify-between gap-3">
                    <h2 className="font-display text-lg font-medium tracking-tight">{story.title}</h2>
                    <span className="shrink-0 text-xs text-faint tabular-nums">{relativeTime(story.lastMessageAt)}</span>
                  </div>
                  <p className="mt-2 line-clamp-2 text-sm text-mute">
                    {story.premise || story.genre || story.tone || "No premise yet — open it and write."}
                  </p>
                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    {cast.slice(0, 4).map((member) => (
                      <span key={member.id} className="flex items-center gap-1.5 text-xs text-mute">
                        <CharacterAvatar name={member.name} mark={member.mark} size="sm" />
                        {member.name}
                      </span>
                    ))}
                    {cast.length > 4 ? <span className="text-xs text-faint">+{cast.length - 4}</span> : null}
                    {story.pinned ? <span className="ml-auto text-xs text-mute">Pinned</span> : null}
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </main>
  );
}
