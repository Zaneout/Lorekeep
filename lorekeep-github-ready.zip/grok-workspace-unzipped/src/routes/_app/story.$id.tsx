import type { ReactNode } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  BookMarked,
  BookOpen,
  ChevronRight,
  LoaderCircle,
  Send,
  Settings2,
  Trash2,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { CharacterAvatar } from "@/components/character-avatar";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { refreshMemory, streamStory } from "@/lib/ai";
import type { Character, Message, MessageKind, Story } from "@/lib/types";
import { useLore } from "@/lib/store";
import { cn, uid } from "@/lib/utils";
import { StoryReader } from "@/components/story-reader";

export const Route = createFileRoute("/_app/story/$id")({
  component: StoryPage,
});

const DIRECTIVES = ["Continue", "Stay in scene", "More body", "Sharper dialogue", "Skip ahead"] as const;

function StoryPage() {
  const { id } = Route.useParams();
  const stories = useLore((s) => s.stories);
  const characters = useLore((s) => s.characters);
  const ready = useLore((s) => s.ready);
  const loadMessages = useLore((s) => s.loadMessages);
  const addMessage = useLore((s) => s.addMessage);
  const updateMessage = useLore((s) => s.updateMessage);
  const upsertStory = useLore((s) => s.upsertStory);
  const deleteStory = useLore((s) => s.deleteStory);
  const navigate = useNavigate();

  const story = stories.find((s) => s.id === id);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [writing, setWriting] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [readerOpen, setReaderOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  const currentChapter = story?.chapters?.find((c) => c.id === story.currentChapterId) ?? story?.chapters?.[0];
  const currentBranch = story?.branches?.find((b) => b.id === story.currentBranchId) ?? story?.branches?.[0];
  const visibleMessages = useMemo(
    () =>
      messages.filter(
        (m) =>
          (!m.chapterId || m.chapterId === story?.currentChapterId) &&
          (!m.branchId || m.branchId === story?.currentBranchId),
      ),
    [messages, story?.currentChapterId, story?.currentBranchId],
  );

  const cast = useMemo(
    () =>
      (story?.characterIds ?? [])
        .map((cid) => characters.find((c) => c.id === cid))
        .filter((c): c is Character => Boolean(c)),
    [story, characters],
  );

  useEffect(() => {
    let cancelled = false;
    setLoaded(false);
    void loadMessages(id).then((rows) => {
      if (cancelled) return;
      setMessages(rows);
      setLoaded(true);
    });
    return () => {
      cancelled = true;
      abortRef.current?.abort();
    };
  }, [id, loadMessages]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [messages, writing]);

  if (!ready) return null;
  if (!story) {
    return (
      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-16">
        <p className="font-display text-2xl">This thread is gone.</p>
        <Link to="/" className="mt-4 text-sm text-mute hover:text-ink">
          Back to the library
        </Link>
      </main>
    );
  }

  async function send(kind: MessageKind, content: string) {
    if (!story || writing) return;
    const text = content.trim();
    if (kind === "chat" && !text) return;

    const userMsg: Message = {
      id: uid(),
      storyId: story.id,
      role: "user",
      kind,
      content: kind === "continue" ? "Continue" : text,
      chapterId: story.currentChapterId,
      branchId: story.currentBranchId,
      createdAt: Date.now(),
    };
    const assistantMsg: Message = {
      id: uid(),
      storyId: story.id,
      role: "assistant",
      kind: "chat",
      content: "",
      chapterId: story.currentChapterId,
      branchId: story.currentBranchId,
      createdAt: Date.now() + 1,
    };

    setDraft("");
    setWriting(true);
    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    await addMessage(userMsg);
    await addMessage(assistantMsg);

    const history = [...messages.filter((m) => !m.branchId || m.branchId === story.currentBranchId), userMsg];
    const controller = new AbortController();
    abortRef.current = controller;
    let assembled = "";

    try {
      assembled = await streamStory(
        {
          story,
          characters: cast,
          messages: history,
        },
        (delta) => {
          assembled += delta;
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantMsg.id ? { ...m, content: assembled } : m)),
          );
        },
        controller.signal,
      );
      const finalText = assembled.trim();
      if (!finalText) throw new Error("The writer returned a blank page.");
      await updateMessage({ ...assistantMsg, content: finalText });
      setMessages((prev) =>
        prev.map((m) => (m.id === assistantMsg.id ? { ...m, content: finalText } : m)),
      );
      void maybeRefreshMemory(story, [...history, { ...assistantMsg, content: finalText }]);
    } catch (error) {
      if ((error as { name?: string }).name === "AbortError") return;
      const message = error instanceof Error ? error.message : "Could not write";
      toast.error(message);
      const failed = { ...assistantMsg, content: assembled.trim() };
      if (failed.content) {
        await updateMessage(failed);
      } else {
        setMessages((prev) => prev.filter((m) => m.id !== assistantMsg.id));
      }
    } finally {
      setWriting(false);
      abortRef.current = null;
    }
  }

  async function maybeRefreshMemory(current: Story, all: Message[]) {
    const unseen = Math.max(0, all.length - current.summarizedCount);
    if (unseen < 10 || all.length < 8) return;
    const older = all.slice(0, Math.max(0, all.length - 6));
    try {
      const memory = await refreshMemory({
        memory: current.memory,
        messages: older.map(({ role, kind, content }) => ({ role, kind, content })),
      });
      await upsertStory({ ...current, memory, summarizedCount: all.length });
    } catch {
      /* memory is best-effort */
    }
  }

  async function onDelete() {
    if (!story) return;
    abortRef.current?.abort();
    await deleteStory(story.id);
    toast("Story removed");
    await navigate({ to: "/" });
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col overflow-hidden">
      <header className="flex items-center gap-2 border-b border-line px-2 py-2 md:px-4">
        <Button variant="ghost" size="icon-sm" asChild>
          <Link to="/" aria-label="Library">
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate font-display text-lg font-medium tracking-tight">{story.title}</h1>
          <p className="truncate text-xs text-mute">
            {[story.genre, story.tone, story.pov].filter(Boolean).join(" · ") || "Open thread"}
          </p>
        </div>
        <div className="hidden items-center sm:flex">
          {cast.slice(0, 3).map((c) => (
            <Link
              key={c.id}
              to="/characters/$id"
              params={{ id: c.id }}
              className="ml-[-6px] first:ml-0"
              title={c.name}
            >
              <CharacterAvatar name={c.name} mark={c.mark} size="sm" />
            </Link>
          ))}
        </div>
        <div className="hidden items-center gap-1 md:flex">
          <select
            aria-label="Chapter"
            value={story.currentChapterId}
            onChange={(e) => void upsertStory({ ...story, currentChapterId: e.target.value })}
            className="h-8 max-w-32 rounded-md bg-panel-2 px-2 text-xs text-ink outline-none"
          >
            {[...(story.chapters ?? [])].sort((a, b) => a.order - b.order).map((chapter) => (
              <option key={chapter.id} value={chapter.id}>{chapter.title}</option>
            ))}
          </select>
          {story.branchingEnabled ? (
            <select
              aria-label="Ending branch"
              value={story.currentBranchId}
              onChange={(e) => void upsertStory({ ...story, currentBranchId: e.target.value })}
              className="h-8 max-w-32 rounded-md bg-panel-2 px-2 text-xs text-ink outline-none"
            >
              {(story.branches ?? []).map((branch) => <option key={branch.id} value={branch.id}>{branch.title}</option>)}
            </select>
          ) : null}
          <Button variant="ghost" size="icon-sm" onClick={() => setReaderOpen(true)} aria-label="Read story">
            <BookOpen className="size-4" />
          </Button>
        </div>
        <Button variant="ghost" size="icon-sm" onClick={() => setSettingsOpen(true)} aria-label="Story settings">
          <Settings2 className="size-4" />
        </Button>
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-6 md:px-8">
        <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col">
          {!loaded ? (
            <p className="m-auto text-sm text-mute">Opening the thread…</p>
          ) : messages.length === 0 ? (
            <EmptyStory story={story} cast={cast} />
          ) : (
            <div className="space-y-8">
              {visibleMessages.map((message) => (
                <MessageBlock
                  key={message.id}
                  message={message}
                  pending={writing && !message.content && message.role === "assistant"}
                />
              ))}
            </div>
          )}
          <div ref={endRef} />
        </div>
      </div>

      <footer className="border-t border-line bg-canvas px-3 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:px-6">
        <div className="mx-auto w-full max-w-2xl">
          <div className="mb-2 flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setReaderOpen(true)}>
              <BookOpen className="size-4" /> Read
            </Button>
            <span className="truncate text-xs text-faint">{currentChapter?.title}{story.branchingEnabled ? ` · ${currentBranch?.title ?? ""}` : ""}</span>
          </div>
          <div className="mb-2 flex gap-1.5 overflow-x-auto pb-1">
            {DIRECTIVES.map((label) => (
              <button
                key={label}
                type="button"
                disabled={writing}
                onClick={() =>
                  void send(label === "Continue" ? "continue" : "directive", label === "Continue" ? "" : label)
                }
                className="h-9 shrink-0 rounded-full px-3 text-xs text-mute shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_12%,transparent)] transition-colors hover:text-ink disabled:opacity-40"
              >
                {label}
              </button>
            ))}
          </div>
          <form
            className="flex items-end gap-2 rounded-xl bg-panel p-2 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_10%,transparent)]"
            onSubmit={(e) => {
              e.preventDefault();
              void send("chat", draft);
            }}
          >
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send("chat", draft);
                }
              }}
              rows={1}
              placeholder={writing ? "Writing…" : "Write, instruct, or paste a scene"}
              disabled={writing}
              className="max-h-40 min-h-11 flex-1 resize-none bg-transparent px-3 py-2.5 text-sm text-ink outline-none placeholder:text-faint"
            />
            <Button type="submit" size="icon" disabled={writing || !draft.trim()} aria-label="Send">
              {writing ? <LoaderCircle className="size-4 animate-spin" /> : <Send className="size-4" />}
            </Button>
          </form>
        </div>
      </footer>

      {readerOpen ? (
        <StoryReader
          messages={visibleMessages}
          title={story.title}
          chapterTitle={currentChapter?.title ?? "Chapter"}
          onClose={() => setReaderOpen(false)}
        />
      ) : null}

      <StorySettings
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        story={story}
        characters={characters}
        onSave={(next) => void upsertStory(next)}
        onDelete={() => void onDelete()}
      />
    </div>
  );
}

function EmptyStory({ story, cast }: { story: Story; cast: Character[] }) {
  return (
    <div className="m-auto max-w-md py-10">
      <p className="text-xs font-medium tracking-[0.14em] text-mute uppercase">Opening</p>
      <h2 className="mt-2 font-display text-3xl font-medium tracking-tight">{story.title}</h2>
      {story.premise ? (
        <p className="mt-3 text-sm leading-relaxed text-mute">{story.premise}</p>
      ) : (
        <p className="mt-3 text-sm text-mute">
          Give an instruction, drop a first line, or tap Continue and let the writer begin.
        </p>
      )}
      {cast.length > 0 ? (
        <ul className="mt-6 space-y-2">
          {cast.map((c) => (
            <li key={c.id}>
              <Link
                to="/characters/$id"
                params={{ id: c.id }}
                className="flex items-center gap-3 text-sm text-ink"
              >
                <CharacterAvatar name={c.name} mark={c.mark} size="sm" />
                <span>{c.name}</span>
                <span className="truncate text-mute">{c.role}</span>
                <ChevronRight className="ml-auto size-4 text-faint" />
              </Link>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

function MessageBlock({ message, pending }: { message: Message; pending?: boolean }) {
  if (message.role === "user") {
    const isChip = message.kind === "continue" || message.kind === "directive";
    return (
      <div className={cn("flex", isChip ? "justify-center" : "justify-end")}>
        <div
          className={cn(
            isChip
              ? "rounded-full px-3 py-1 text-xs text-mute shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_12%,transparent)]"
              : "max-w-[min(100%,36rem)] rounded-lg bg-panel-2 px-4 py-3 text-sm leading-relaxed text-ink",
          )}
        >
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <article className="max-w-none">
      {pending ? (
        <p className="text-sm text-mute">Writing</p>
      ) : (
        <div className="whitespace-pre-wrap font-display text-lg leading-[1.7] text-ink">
          {message.content}
        </div>
      )}
    </article>
  );
}

function StorySettings({
  open,
  onOpenChange,
  story,
  characters,
  onSave,
  onDelete,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  story: Story;
  characters: Character[];
  onSave: (story: Story) => void;
  onDelete: () => void;
}) {
  const [local, setLocal] = useState(story);

  useEffect(() => {
    if (open) setLocal(story);
  }, [open, story]);

  function patch<K extends keyof Story>(key: K, value: Story[K]) {
    setLocal((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[min(90dvh,40rem)] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Thread</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Title">
            <Input value={local.title} onChange={(e) => patch("title", e.target.value)} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Genre">
              <Input value={local.genre} onChange={(e) => patch("genre", e.target.value)} />
            </Field>
            <Field label="Tone">
              <Input value={local.tone} onChange={(e) => patch("tone", e.target.value)} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="POV">
              <Input value={local.pov} onChange={(e) => patch("pov", e.target.value)} />
            </Field>
            <Field label="Setting">
              <Input value={local.setting} onChange={(e) => patch("setting", e.target.value)} />
            </Field>
          </div>
          <Field label="Premise">
            <Textarea rows={3} value={local.premise} onChange={(e) => patch("premise", e.target.value)} />
          </Field>
          <Field label="Living memory">
            <Textarea
              rows={6}
              value={local.memory}
              onChange={(e) => patch("memory", e.target.value)}
              placeholder="Facts the writer should never forget. This grows as the thread does."
            />
          </Field>
          <div className="space-y-1.5">
            <Label>Cast</Label>
            <div className="flex flex-wrap gap-2">
              {characters.map((character) => {
                const on = local.characterIds.includes(character.id);
                return (
                  <button
                    key={character.id}
                    type="button"
                    onClick={() =>
                      patch(
                        "characterIds",
                        on
                          ? local.characterIds.filter((cid) => cid !== character.id)
                          : [...local.characterIds, character.id],
                      )
                    }
                    className={cn(
                      "flex h-11 items-center gap-2 rounded-md px-2.5 text-sm",
                      on ? "bg-accent text-accent-fg" : "bg-panel-2 text-ink",
                    )}
                  >
                    <CharacterAvatar name={character.name} mark={character.mark} size="sm" />
                    {character.name}
                  </button>
                );
              })}
            </div>
            {characters.length === 0 ? (
              <p className="text-xs text-mute">
                <Link to="/characters" className="underline-offset-2 hover:underline">
                  Add a character profile
                </Link>{" "}
                to pin a cast to this thread.
              </p>
            ) : null}
          </div>
          <div className="flex items-center justify-between pt-2">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" className="text-danger">
                  <Trash2 className="size-4" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this story?</AlertDialogTitle>
                  <AlertDialogDescription>
                    The thread and its memory leave this device. Character profiles stay.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Keep</AlertDialogCancel>
                  <AlertDialogAction onClick={onDelete}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <Button
              onClick={() => {
                onSave({ ...local, title: local.title.trim() || "Untitled story" });
                onOpenChange(false);
                toast("Thread updated");
              }}
            >
              <BookMarked className="size-4" />
              Save
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
