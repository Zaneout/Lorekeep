import type { ReactNode } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, BookOpen, Check, Pencil, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { CharacterAvatar } from "@/components/character-avatar";
import { NewStoryDialog } from "@/components/new-story-dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { MARKS, type Character, type Mark } from "@/lib/types";
import { useLore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/characters/$id")({
  component: CharacterProfilePage,
});

const SECTIONS: { key: keyof Character; label: string; hint: string; rows?: number }[] = [
  { key: "appearance", label: "Appearance", hint: "What the page should always see.", rows: 5 },
  { key: "personality", label: "Personality", hint: "How they move through a scene.", rows: 5 },
  { key: "voice", label: "Voice", hint: "Rhythm, diction, what they never say.", rows: 4 },
  { key: "backstory", label: "Backstory", hint: "Only what still exerts pressure.", rows: 6 },
  { key: "secrets", label: "Secrets", hint: "Held close. The writer still knows.", rows: 4 },
  { key: "relationships", label: "Relationships", hint: "Who they orbit, owe, or avoid.", rows: 4 },
  { key: "alwaysRemember", label: "Always remember", hint: "Injected into every story they enter.", rows: 4 },
  { key: "notes", label: "Author notes", hint: "Private craft notes. Not spoken aloud.", rows: 4 },
];

function CharacterProfilePage() {
  const { id } = Route.useParams();
  const characters = useLore((s) => s.characters);
  const stories = useLore((s) => s.stories);
  const upsertCharacter = useLore((s) => s.upsertCharacter);
  const deleteCharacter = useLore((s) => s.deleteCharacter);
  const ready = useLore((s) => s.ready);
  const navigate = useNavigate();
  const stored = characters.find((c) => c.id === id);
  const [draft, setDraft] = useState<Character | null>(stored ?? null);
  const [editing, setEditing] = useState(false);
  const [tagDraft, setTagDraft] = useState("");

  useEffect(() => {
    if (stored) {
      setDraft(stored);
      setTagDraft(stored.tags.join(", "));
      if (!stored.name || stored.name === "New character") setEditing(true);
    }
  }, [stored]);

  const appearing = useMemo(
    () => stories.filter((s) => s.characterIds.includes(id)).sort((a, b) => b.lastMessageAt - a.lastMessageAt),
    [stories, id],
  );

  if (!ready) return null;
  if (!stored || !draft) {
    return (
      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-16">
        <p className="font-display text-2xl">This profile is gone.</p>
        <Link to="/characters" className="mt-4 text-sm text-mute hover:text-ink">
          Back to the cast
        </Link>
      </main>
    );
  }

  function patch<K extends keyof Character>(key: K, value: Character[K]) {
    setDraft((prev) => (prev ? { ...prev, [key]: value } : prev));
  }

  async function save() {
    if (!draft) return;
    const tags = tagDraft
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
    await upsertCharacter({ ...draft, tags, name: draft.name.trim() || "Unnamed" });
    setEditing(false);
    toast("Profile saved");
  }

  async function onDelete() {
    await deleteCharacter(id);
    toast("Character removed");
    await navigate({ to: "/characters" });
  }

  return (
    <main className="mx-auto w-full max-w-3xl flex-1 px-4 pt-4 pb-16 md:px-8 md:pt-8">
      <div className="mb-6 flex items-center justify-between gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/characters">
            <ArrowLeft className="size-4" />
            Cast
          </Link>
        </Button>
        <div className="flex items-center gap-1">
          {editing ? (
            <Button size="sm" onClick={() => void save()}>
              <Check className="size-4" />
              Save
            </Button>
          ) : (
            <Button variant="secondary" size="sm" onClick={() => setEditing(true)}>
              <Pencil className="size-4" />
              Edit
            </Button>
          )}
        </div>
      </div>

      <header className="flex flex-col gap-5 sm:flex-row sm:items-end">
        <button
          type="button"
          disabled={!editing}
          onClick={() => {
            const i = MARKS.indexOf(draft.mark);
            patch("mark", MARKS[(i + 1) % MARKS.length] as Mark);
          }}
          className={cn("self-start", editing && "cursor-pointer")}
          aria-label="Cycle mark color"
        >
          <CharacterAvatar name={draft.name} mark={draft.mark} size="xl" />
        </button>
        <div className="min-w-0 flex-1">
          {editing ? (
            <div className="space-y-2">
              <Input
                value={draft.name}
                onChange={(e) => patch("name", e.target.value)}
                className="h-12 font-display text-2xl"
                placeholder="Name"
              />
              <Input
                value={draft.role}
                onChange={(e) => patch("role", e.target.value)}
                placeholder="Role or epithet"
              />
            </div>
          ) : (
            <>
              <h1 className="font-display text-4xl font-medium tracking-tight">{draft.name}</h1>
              <p className="mt-1 text-base text-mute">{draft.role || "No role yet"}</p>
            </>
          )}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {draft.tags.map((tag) => (
              <Badge key={tag}>{tag}</Badge>
            ))}
            {!editing && appearing.length > 0 ? (
              <Badge>{appearing.length === 1 ? "1 story" : `${appearing.length} stories`}</Badge>
            ) : null}
          </div>
        </div>
      </header>

      {editing ? (
        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          <Field label="Aliases">
            <Input value={draft.aliases} onChange={(e) => patch("aliases", e.target.value)} />
          </Field>
          <Field label="Tags">
            <Input
              value={tagDraft}
              onChange={(e) => setTagDraft(e.target.value)}
              placeholder="comma separated"
            />
          </Field>
          <Field label="Age">
            <Input value={draft.age} onChange={(e) => patch("age", e.target.value)} />
          </Field>
          <Field label="Gender">
            <Input value={draft.gender} onChange={(e) => patch("gender", e.target.value)} />
          </Field>
        </div>
      ) : (
        <dl className="mt-8 grid grid-cols-2 gap-x-6 gap-y-3 text-sm sm:grid-cols-3">
          <Meta label="Aliases" value={draft.aliases} />
          <Meta label="Age" value={draft.age} />
          <Meta label="Gender" value={draft.gender} />
        </dl>
      )}

      <div className="mt-10 space-y-8">
        {SECTIONS.map((section) => {
          const value = String(draft[section.key] ?? "");
          if (!editing && !value.trim()) return null;
          return (
            <section key={section.key}>
              <h2 className="text-xs font-medium tracking-[0.14em] text-mute uppercase">{section.label}</h2>
              {editing ? (
                <>
                  <p className="mt-1 text-xs text-faint">{section.hint}</p>
                  <Textarea
                    className="mt-2 min-h-28"
                    rows={section.rows}
                    value={value}
                    onChange={(e) => patch(section.key, e.target.value as never)}
                  />
                </>
              ) : (
                <p className="mt-2 whitespace-pre-wrap font-display text-[1.05rem] leading-relaxed text-ink">
                  {value}
                </p>
              )}
            </section>
          );
        })}
      </div>

      <section className="mt-12">
        <h2 className="text-xs font-medium tracking-[0.14em] text-mute uppercase">Stories</h2>
        {appearing.length === 0 ? (
          <p className="mt-3 text-sm text-mute">Not cast in a story yet.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {appearing.map((story) => (
              <li key={story.id}>
                <Link
                  to="/story/$id"
                  params={{ id: story.id }}
                  className="flex items-center gap-3 rounded-lg bg-panel px-3 py-3 text-sm shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_8%,transparent)]"
                >
                  <BookOpen className="size-4 text-mute" />
                  <span className="font-medium">{story.title}</span>
                  <span className="ml-auto text-xs text-faint">{story.genre}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
        <NewStoryDialog presetCharacterId={draft.id}>
          <Button className="mt-4">Write with {draft.name.split(" ")[0] || "them"}</Button>
        </NewStoryDialog>
      </section>

      <div className="mt-16 border-t border-line pt-6">
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" className="text-danger">
              <Trash2 className="size-4" />
              Delete character
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete {draft.name}?</AlertDialogTitle>
              <AlertDialogDescription>
                The profile is removed from this device. Stories stay; they simply lose this name from the cast.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep</AlertDialogCancel>
              <AlertDialogAction onClick={() => void onDelete()}>Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </main>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  if (!value) return null;
  return (
    <div>
      <dt className="text-xs text-faint">{label}</dt>
      <dd className="mt-0.5 text-ink">{value}</dd>
    </div>
  );
}
