import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/story")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { readLimitedJson, streamGrokStory } = await import("@/lib/xai.server");
        try {
          const text = await request.text();
          const body = readLimitedJson(text);
          return await streamGrokStory(body);
        } catch (error) {
          const status = (error as { status?: number }).status ?? 400;
          const message = error instanceof Error ? error.message : "Bad request";
          return Response.json({ error: message }, { status });
        }
      },
    },
  },
});
