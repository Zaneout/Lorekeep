import type { ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CharacterAvatar } from "@/components/character-avatar";
import { useLore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function NewStoryDialog({
  children,
  presetCharacterId,
}: {
  children: ReactNode;
  presetCharacterId?: string;
}) {
  const navigate = useNavigate();
  const characters = useLore((s) => s.characters);
  const createStory = useLore((s) => s.createStory);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [premise, setPremise] = useState("");
  const [genre, setGenre] = useState("");
  const [tone, setTone] = useState("");
  const [cast, setCast] = useState<string[]>(presetCharacterId ? [presetCharacterId] : []);
  const [chapterCount, setChapterCount] = useState(1);
  const [branchingEnabled, setBranchingEnabled] = useState(false);
  const [busy, setBusy] = useState(false);

  const ordered = useMemo(
    () => [...characters].sort((a, b) => a.name.localeCompare(b.name)),
    [characters],
  );

  async function start() {
    setBusy(true);
    try {
      const story = await createStory({
        title: title.trim() || "Untitled story",
        premise: premise.trim(),
        genre: genre.trim(),
        tone: tone.trim(),
        characterIds: cast,
        chapters: Array.from({ length: Math.max(1, chapterCount) }, (_, i) => ({
          id: crypto.randomUUID(),
          title: `Chapter ${i + 1}`,
          order: i,
        })),
        branchingEnabled,
        branches: branchingEnabled
          ? [
              { id: crypto.randomUUID(), title: "Ending A", prompt: "" },
              { id: crypto.randomUUID(), title: "Ending B", prompt: "" },
            ]
          : [{ id: crypto.randomUUID(), title: "Main ending", prompt: "" }],
      });
      setOpen(false);
      setTitle("");
      setPremise("");
      setGenre("");
      setTone("");
      setChapterCount(1);
      setBranchingEnabled(false);
      setCast(presetCharacterId ? [presetCharacterId] : []);
      await navigate({ to: "/story/$id", params: { id: story.id } });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New story</DialogTitle>
          <DialogDescription>Open a thread. Memory stays with it forever.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="story-title">Title</Label>
            <Input
              id="story-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="The Salt Road"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="story-genre">Genre</Label>
              <Input
                id="story-genre"
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                placeholder="Noir fantasy"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="story-tone">Tone</Label>
              <Input
                id="story-tone"
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                placeholder="Intimate, unhurried"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="chapter-count">Chapters</Label>
              <Input
                id="chapter-count"
                type="number"
                min={1}
                max={30}
                value={chapterCount}
                onChange={(e) => setChapterCount(Math.min(30, Math.max(1, Number(e.target.value) || 1)))}
              />
            </div>
            <label className="flex items-end gap-2 pb-2 text-sm text-mute">
              <input
                type="checkbox"
                checked={branchingEnabled}
                onChange={(e) => setBranchingEnabled(e.target.checked)}
              />
              Two possible endings
            </label>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="story-premise">Premise</Label>
            <Textarea
              id="story-premise"
              value={premise}
              onChange={(e) => setPremise(e.target.value)}
              placeholder="What is this story about?"
              rows={3}
            />
          </div>
          {ordered.length > 0 ? (
            <div className="space-y-1.5">
              <Label>Cast</Label>
              <div className="flex flex-wrap gap-2">
                {ordered.map((character) => {
                  const on = cast.includes(character.id);
                  return (
                    <button
                      key={character.id}
                      type="button"
                      onClick={() =>
                        setCast((prev) =>
                          on ? prev.filter((id) => id !== character.id) : [...prev, character.id],
                        )
                      }
                      className={cn(
                        "flex h-11 items-center gap-2 rounded-md px-2.5 text-sm transition-colors",
                        on ? "bg-accent text-accent-fg" : "bg-panel-2 text-ink",
                      )}
                    >
                      <CharacterAvatar name={character.name} mark={character.mark} size="sm" />
                      {character.name || "Unnamed"}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : null}
          <div className="flex justify-end pt-2">
            <Button onClick={() => void start()} disabled={busy}>
              {busy ? "Opening…" : "Open story"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
