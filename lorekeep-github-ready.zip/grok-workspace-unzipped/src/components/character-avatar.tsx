import type { Mark } from "@/lib/types";
import { cn, initials } from "@/lib/utils";

const markClass: Record<Mark, string> = {
  slate: "bg-mark-slate",
  olive: "bg-mark-olive",
  umber: "bg-mark-umber",
  steel: "bg-mark-steel",
  moss: "bg-mark-moss",
  dusk: "bg-mark-dusk",
};

export function CharacterAvatar({
  name,
  mark,
  size = "md",
  className,
}: {
  name: string;
  mark: Mark;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  const box =
    size === "sm"
      ? "size-8 text-[10px] rounded-sm"
      : size === "lg"
        ? "size-16 text-lg rounded-lg"
        : size === "xl"
          ? "size-24 text-2xl rounded-xl"
          : "size-11 text-xs rounded-md";

  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center justify-center font-display font-medium tracking-wide text-canvas",
        markClass[mark],
        box,
        className,
      )}
      aria-hidden
    >
      {initials(name || "New")}
    </span>
  );
}
