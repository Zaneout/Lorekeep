import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, Download, Users } from "lucide-react";
import { useEffect } from "react";
import { TooltipProvider } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { useLore } from "@/lib/store";

const NAV = [
  { to: "/", label: "Stories", icon: BookOpen, match: (p: string) => p === "/" || p.startsWith("/story") },
  { to: "/characters", label: "Characters", icon: Users, match: (p: string) => p.startsWith("/characters") },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hydrate = useLore((s) => s.hydrate);
  const ready = useLore((s) => s.ready);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  const hideChrome = pathname.startsWith("/story/");

  return (
    <TooltipProvider>
      <div className="flex h-dvh flex-col overflow-hidden bg-canvas text-ink md:flex-row">
        <aside
          className={cn(
            "hidden shrink-0 flex-col border-r border-line md:flex md:w-56 lg:w-60",
            hideChrome && "md:hidden",
          )}
        >
          <div className="px-5 pt-6 pb-4">
            <Link to="/" className="block">
              <p className="font-display text-xl font-medium tracking-tight">Lorekeep</p>
              <p className="mt-1 text-xs text-mute">Private story studio</p>
            </Link>
          </div>
          <nav className="flex flex-1 flex-col gap-1 px-3">
            {NAV.map((item) => {
              const active = item.match(pathname);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-11 items-center gap-2.5 rounded-md px-3 text-sm font-medium transition-colors duration-150",
                    active ? "bg-panel-2 text-ink" : "text-mute hover:bg-panel hover:text-ink",
                  )}
                >
                  <item.icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <InstallHint className="mx-3 mb-4" />
        </aside>

        <div
          className={cn(
            "flex min-h-0 min-w-0 flex-1 flex-col",
            hideChrome ? "overflow-hidden" : "overflow-y-auto",
          )}
        >
          {ready ? children : <LoadingStudio />}
        </div>

        {!hideChrome ? (
          <nav className="sticky bottom-0 z-30 flex border-t border-line bg-canvas/95 pb-[env(safe-area-inset-bottom)] md:hidden">
            {NAV.map((item) => {
              const active = item.match(pathname);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-14 flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                    active ? "text-ink" : "text-mute",
                  )}
                >
                  <item.icon className="size-5" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        ) : null}
      </div>
    </TooltipProvider>
  );
}

function LoadingStudio() {
  return <div className="flex flex-1 items-center justify-center text-sm text-mute">Opening the studio…</div>;
}

function InstallHint({ className }: { className?: string }) {
  const standalone =
    typeof window !== "undefined" &&
    (window.matchMedia("(display-mode: standalone)").matches ||
      ("standalone" in window.navigator && Boolean((window.navigator as { standalone?: boolean }).standalone)));

  if (standalone) return null;

  return (
    <a
      href="/?install=1"
      className={cn(
        "flex h-11 items-center gap-2 rounded-md px-3 text-sm text-mute transition-colors hover:bg-panel hover:text-ink",
        className,
      )}
    >
      <Download className="size-4" />
      Install app
    </a>
  );
}
