import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

function Badge({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium text-mute shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-ink)_12%,transparent)]",
        className,
      )}
    >
      {children}
    </span>
  );
}

export { Badge };
