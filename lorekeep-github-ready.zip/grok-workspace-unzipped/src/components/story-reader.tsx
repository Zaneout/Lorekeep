import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { useMemo, useState } from "react";
import type { Message } from "@/lib/types";
import { Button } from "@/components/ui/button";

export function StoryReader({
  messages,
  title,
  chapterTitle,
  onClose,
}: {
  messages: Message[];
  title: string;
  chapterTitle: string;
  onClose: () => void;
}) {
  const pages = useMemo(() => {
    const paragraphs = messages
      .filter((m) => m.role === "assistant" && m.content.trim())
      .flatMap((m) => m.content.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean));
    const out: string[] = [];
    let current = "";
    for (const paragraph of paragraphs) {
      if ((current.length + paragraph.length > 1200) && current) {
        out.push(current);
        current = "";
      }
      current = current ? `${current}\n\n${paragraph}` : paragraph;
    }
    if (current) out.push(current);
    return out.length ? out : ["The book is waiting for its first page."];
  }, [messages]);
  const [page, setPage] = useState(0);
  const [turning, setTurning] = useState(false);

  function turn(next: number) {
    if (next < 0 || next >= pages.length || next === page) return;
    setTurning(true);
    window.setTimeout(() => {
      setPage(next);
      setTurning(false);
    }, 240);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 md:p-8" role="dialog" aria-label="Story reader">
      <div className="relative flex h-[min(88dvh,760px)] w-full max-w-4xl flex-col overflow-hidden rounded-2xl bg-[#e9e1d2] text-[#241f19] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#241f19]/10 px-5 py-3">
          <div className="min-w-0">
            <p className="truncate font-display text-lg">{title}</p>
            <p className="truncate text-xs opacity-60">{chapterTitle} · Page {page + 1} of {pages.length}</p>
          </div>
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="Close reader"><X className="size-4" /></Button>
        </div>
        <div className="flex min-h-0 flex-1 items-center justify-center p-4 md:p-10">
          <article
            className={`book-page h-full w-full max-w-2xl overflow-y-auto rounded-sm bg-[#f5eee2] p-7 shadow-[0_8px_35px_rgba(0,0,0,.18)] md:p-12 ${turning ? "book-page-turn" : ""}`}
          >
            <div className="mx-auto max-w-xl whitespace-pre-wrap font-display text-[1.08rem] leading-[1.9] md:text-[1.18rem]">
              {pages[page]}
            </div>
          </article>
        </div>
        <div className="flex items-center justify-center gap-5 border-t border-[#241f19]/10 px-5 py-3">
          <Button variant="ghost" size="icon" disabled={page === 0} onClick={() => turn(page - 1)} aria-label="Previous page"><ChevronLeft /></Button>
          <span className="text-xs opacity-60">Turn the page</span>
          <Button variant="ghost" size="icon" disabled={page === pages.length - 1} onClick={() => turn(page + 1)} aria-label="Next page"><ChevronRight /></Button>
        </div>
      </div>
    </div>
  );
}
