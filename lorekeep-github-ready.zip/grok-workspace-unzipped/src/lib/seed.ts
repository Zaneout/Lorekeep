import type { Character } from "@/lib/types";
import { uid, now } from "@/lib/utils";

export function sampleCharacters(): Character[] {
  const t = now();
  return [
    {
      id: uid(),
      name: "Vesper Hale",
      role: "Night broker of the drowned wards",
      aliases: "The Pale Ledger, Hale",
      age: "34",
      gender: "Woman",
      appearance:
        "Ink-dark hair cropped at the jaw, a thin gold-cut scar through the left brow, and the kind of stillness people mistake for patience. She dresses in salt-stained coats two sizes too fine for the docks. Always a charcoal pencil behind one ear.",
      personality:
        "Measured, dry, and loyal to contracts more than causes. She keeps score in her head and rarely raises her voice. Kindness arrives as practical help, never as comfort. She hates being owed, and hates owing more.",
      voice:
        "Low, unhurried, slightly hoarse from the river fog. Speaks in short clauses. Swears rarely, and only when a deal is already dead. Calls people by their full names when she is angry.",
      backstory:
        "Raised in the counting rooms above the old ferry. After the flood took the lower city, she stayed to buy and sell what the water couldn't swallow: names, routes, and quiet. She once smuggled a choir out of a burning chapel and still pretends it was only business.",
      secrets:
        "She keeps a second ledger written in her sister's hand — a sister the city believes drowned. She is looking for the man who sold the floodgates.",
      relationships:
        "Ilya Voss is the only mapmaker she trusts with a blank page. She owes a blood-debt to a dock priest she will not name. The harbor master wants her gone.",
      alwaysRemember:
        "Never breaks a signed deal. Cannot swim. Keeps her sister's brass compass in the left coat pocket.",
      notes: "",
      tags: ["broker", "docks", "contracts"],
      mark: "steel",
      createdAt: t,
      updatedAt: t,
    },
    {
      id: uid(),
      name: "Ilya Voss",
      role: "Cartographer of places that should not exist",
      aliases: "Voss, the Dreamsurveyor",
      age: "29",
      gender: "Man",
      appearance:
        "Tall, slightly stooped from tables, with ink under the nails and a faint constellation of burn scars on the right wrist. Copper-wire glasses. Clothes that were expensive once and have since been lived in. A satchel that never quite closes.",
      personality:
        "Curious to the point of recklessness, then suddenly careful. Talks with his hands. Romantic about maps, cynical about people who commission them. Sleeps little. Notices thresholds, stains, and lies.",
      voice:
        "Quick, warm, a little academic until the subject turns dangerous. Then he drops into a hush. Uses the names of streets as if they were old friends.",
      backstory:
        "Trained at the Imperial Survey, then expelled for publishing a chart of a city that had not been built yet — and was, two years later. He now takes private work: lost rooms, sealed wards, and the interiors of other people's dreams.",
      secrets:
        "Some of his maps update themselves overnight. He has started dreaming in a handwriting that is not his.",
      relationships:
        "Vesper Hale pays him in coin and in questions. He is in love with a client he has never seen in daylight. His former master wants the dream-charts back.",
      alwaysRemember:
        "Draws while he thinks. Will not enter a room without noting the exits. Allergic to myrrh.",
      notes: "",
      tags: ["maps", "dreams", "scholar"],
      mark: "olive",
      createdAt: t + 1,
      updatedAt: t + 1,
    },
  ];
}
