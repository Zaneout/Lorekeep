import { create } from "zustand";
import type { Character, Message, Story } from "@/lib/types";
import { MARKS, type LoreDump, type Mark } from "@/lib/types";
import {
  idbDelete,
  idbDeleteMessagesForStory,
  idbExportDump,
  idbGetAll,
  idbGetMeta,
  idbImportDump,
  idbMessagesForStory,
  idbPut,
  idbSetMeta,
} from "@/lib/idb";
import { sampleCharacters } from "@/lib/seed";
import { now, uid } from "@/lib/utils";

function blankCharacter(partial?: Partial<Character>): Character {
  const t = now();
  return {
    id: uid(),
    name: "",
    role: "",
    aliases: "",
    age: "",
    gender: "",
    appearance: "",
    personality: "",
    voice: "",
    backstory: "",
    secrets: "",
    relationships: "",
    alwaysRemember: "",
    notes: "",
    tags: [],
    mark: MARKS[Math.floor(Math.random() * MARKS.length)] as Mark,
    createdAt: t,
    updatedAt: t,
    ...partial,
  };
}

function blankStory(partial?: Partial<Story>): Story {
  const t = now();
  const chapterId = uid();
  const branchId = uid();
  return {
    id: uid(),
    title: "Untitled story",
    premise: "",
    genre: "",
    tone: "",
    pov: "Third limited",
    setting: "",
    characterIds: [],
    memory: "",
    summarizedCount: 0,
    pinned: false,
    createdAt: t,
    updatedAt: t,
    lastMessageAt: t,
    chapters: [{ id: chapterId, title: "Chapter 1", order: 0 }],
    currentChapterId: chapterId,
    branchingEnabled: false,
    branches: [{ id: branchId, title: "Main ending", prompt: "" }],
    currentBranchId: branchId,
    ...partial,
  };
}

type LoreState = {
  ready: boolean;
  characters: Character[];
  stories: Story[];
  hydrate: () => Promise<void>;
  upsertCharacter: (character: Character) => Promise<Character>;
  createCharacter: (partial?: Partial<Character>) => Promise<Character>;
  deleteCharacter: (id: string) => Promise<void>;
  upsertStory: (story: Story) => Promise<Story>;
  createStory: (partial?: Partial<Story>) => Promise<Story>;
  deleteStory: (id: string) => Promise<void>;
  loadMessages: (storyId: string) => Promise<Message[]>;
  addMessage: (message: Omit<Message, "id" | "createdAt"> & { id?: string; createdAt?: number }) => Promise<Message>;
  updateMessage: (message: Message) => Promise<void>;
  exportAll: () => Promise<LoreDump>;
  importAll: (dump: LoreDump) => Promise<void>;
};

export const useLore = create<LoreState>((set, get) => ({
  ready: false,
  characters: [],
  stories: [],

  hydrate: async () => {
    try {
      if (typeof indexedDB === "undefined") {
        set({ ready: true });
        return;
      }
      let characters = await idbGetAll<Character>("characters");
      const stories = await idbGetAll<Story>("stories");
      const seeded = await idbGetMeta<boolean>("seeded");
      if (!seeded && characters.length === 0) {
        const samples = sampleCharacters();
        for (const character of samples) await idbPut("characters", character);
        await idbSetMeta("seeded", true);
        characters = samples;
      }
      const normalizedStories = stories.map((story) => {
        const chapterId = story.currentChapterId || uid();
        const branchId = story.currentBranchId || uid();
        return {
          ...story,
          chapters: story.chapters?.length ? story.chapters : [{ id: chapterId, title: "Chapter 1", order: 0 }],
          currentChapterId: chapterId,
          branchingEnabled: story.branchingEnabled ?? false,
          branches: story.branches?.length ? story.branches : [{ id: branchId, title: "Main ending", prompt: "" }],
          currentBranchId: branchId,
        };
      });
      set({
        ready: true,
        characters: characters.sort((a, b) => b.updatedAt - a.updatedAt),
        stories: normalizedStories.sort((a, b) => b.lastMessageAt - a.lastMessageAt),
      });
    } catch (error) {
      console.error("Lorekeep failed to open local memory", error);
      set({ ready: true });
    }
  },

  upsertCharacter: async (character) => {
    const next = { ...character, updatedAt: now() };
    await idbPut("characters", next);
    set({
      characters: [next, ...get().characters.filter((c) => c.id !== next.id)].sort(
        (a, b) => b.updatedAt - a.updatedAt,
      ),
    });
    return next;
  },

  createCharacter: async (partial) => {
    const character = blankCharacter(partial);
    return get().upsertCharacter(character);
  },

  deleteCharacter: async (id) => {
    await idbDelete("characters", id);
    const stories = get().stories;
    for (const story of stories) {
      if (!story.characterIds.includes(id)) continue;
      const next = {
        ...story,
        characterIds: story.characterIds.filter((cid) => cid !== id),
        updatedAt: now(),
      };
      await idbPut("stories", next);
    }
    set({
      characters: get().characters.filter((c) => c.id !== id),
      stories: get().stories.map((s) =>
        s.characterIds.includes(id)
          ? { ...s, characterIds: s.characterIds.filter((cid) => cid !== id) }
          : s,
      ),
    });
  },

  upsertStory: async (story) => {
    const next = { ...story, updatedAt: now() };
    await idbPut("stories", next);
    set({
      stories: [next, ...get().stories.filter((s) => s.id !== next.id)].sort(
        (a, b) => b.lastMessageAt - a.lastMessageAt,
      ),
    });
    return next;
  },

  createStory: async (partial) => {
    const story = blankStory(partial);
    const chapters = story.chapters?.length ? story.chapters : [{ id: uid(), title: "Chapter 1", order: 0 }];
    const branches = story.branches?.length ? story.branches : [{ id: uid(), title: "Main ending", prompt: "" }];
    const normalized = {
      ...story,
      chapters,
      currentChapterId: chapters.some((c) => c.id === story.currentChapterId) ? story.currentChapterId : chapters[0].id,
      branches,
      currentBranchId: branches.some((b) => b.id === story.currentBranchId) ? story.currentBranchId : branches[0].id,
    };
    return get().upsertStory(normalized);
  },

  deleteStory: async (id) => {
    await idbDeleteMessagesForStory(id);
    await idbDelete("stories", id);
    set({ stories: get().stories.filter((s) => s.id !== id) });
  },

  loadMessages: async (storyId) => {
    if (typeof indexedDB === "undefined") return [];
    return idbMessagesForStory(storyId);
  },

  addMessage: async (input) => {
    const message: Message = {
      id: input.id ?? uid(),
      storyId: input.storyId,
      role: input.role,
      kind: input.kind,
      content: input.content,
      chapterId: input.chapterId,
      branchId: input.branchId,
      createdAt: input.createdAt ?? now(),
    };
    await idbPut("messages", message);
    const story = get().stories.find((s) => s.id === message.storyId);
    if (story) {
      await get().upsertStory({ ...story, lastMessageAt: message.createdAt });
    }
    return message;
  },

  updateMessage: async (message) => {
    await idbPut("messages", message);
  },

  exportAll: async () => idbExportDump(),

  importAll: async (dump) => {
    await idbImportDump(dump);
    await get().hydrate();
  },
}));

export { blankCharacter, blankStory };
