const WINDOW_MS = 10 * 60 * 1000;
const MAX_HITS = 40;
const hits: number[] = [];

export function allowAiCall(): boolean {
  const now = Date.now();
  while (hits.length && now - hits[0]! > WINDOW_MS) hits.shift();
  if (hits.length >= MAX_HITS) return false;
  hits.push(now);
  return true;
}
