import type { Character, LoreDump, Message, Story } from "@/lib/types";

const DB_NAME = "lorekeep";
const DB_VERSION = 2;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("characters")) {
        db.createObjectStore("characters", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("stories")) {
        db.createObjectStore("stories", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("messages")) {
        const store = db.createObjectStore("messages", { keyPath: "id" });
        store.createIndex("byStory", "storyId", { unique: false });
      }
      if (!db.objectStoreNames.contains("meta")) {
        db.createObjectStore("meta", { keyPath: "key" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function reqToPromise<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

async function withStore<T>(
  store: "characters" | "stories" | "messages" | "meta",
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest<T> | Promise<T>,
): Promise<T> {
  const db = await openDb();
  try {
    const tx = db.transaction(store, mode);
    const finished = txDone(tx);
    const objectStore = tx.objectStore(store);
    const result = fn(objectStore);
    const value = result instanceof Promise ? await result : await reqToPromise(result);
    await finished;
    return value;
  } finally {
    db.close();
  }
}

export async function idbGetAll<T>(store: "characters" | "stories" | "messages"): Promise<T[]> {
  return withStore(store, "readonly", (s) => s.getAll() as IDBRequest<T[]>);
}

export async function idbPut(
  store: "characters" | "stories" | "messages",
  value: Character | Story | Message,
): Promise<void> {
  await withStore(store, "readwrite", (s) => s.put(value));
}

export async function idbDelete(
  store: "characters" | "stories" | "messages",
  id: string,
): Promise<void> {
  await withStore(store, "readwrite", (s) => s.delete(id));
}

export async function idbMessagesForStory(storyId: string): Promise<Message[]> {
  const db = await openDb();
  try {
    const tx = db.transaction("messages", "readonly");
    const finished = txDone(tx);
    const index = tx.objectStore("messages").index("byStory");
    const rows = await reqToPromise(index.getAll(storyId) as IDBRequest<Message[]>);
    await finished;
    return rows.sort((a, b) => a.createdAt - b.createdAt);
  } finally {
    db.close();
  }
}

export async function idbDeleteMessagesForStory(storyId: string): Promise<void> {
  const messages = await idbMessagesForStory(storyId);
  const db = await openDb();
  try {
    const tx = db.transaction("messages", "readwrite");
    const finished = txDone(tx);
    const store = tx.objectStore("messages");
    for (const message of messages) store.delete(message.id);
    await finished;
  } finally {
    db.close();
  }
}

export async function idbGetMeta<T>(key: string): Promise<T | undefined> {
  const row = await withStore(
    "meta",
    "readonly",
    (s) => s.get(key) as IDBRequest<{ key: string; value: T } | undefined>,
  );
  return row?.value;
}

export async function idbSetMeta<T>(key: string, value: T): Promise<void> {
  await withStore("meta", "readwrite", (s) => s.put({ key, value }));
}

export async function idbImportDump(dump: LoreDump): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(["characters", "stories", "messages"], "readwrite");
    const finished = txDone(tx);
    const characters = tx.objectStore("characters");
    const stories = tx.objectStore("stories");
    const messages = tx.objectStore("messages");
    for (const character of dump.characters) characters.put(character);
    for (const story of dump.stories) stories.put(story);
    for (const message of dump.messages) messages.put(message);
    await finished;
  } finally {
    db.close();
  }
}

export async function idbExportDump(): Promise<LoreDump> {
  const [characters, stories, messages] = await Promise.all([
    idbGetAll<Character>("characters"),
    idbGetAll<Story>("stories"),
    idbGetAll<Message>("messages"),
  ]);
  return { version: 2, exportedAt: Date.now(), characters, stories, messages };
}
