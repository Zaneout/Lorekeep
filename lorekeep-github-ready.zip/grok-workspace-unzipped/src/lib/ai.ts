import type { Character, Message, Story } from "@/lib/types";

export type StoryRequest = {
  story: Pick<Story, "title" | "premise" | "genre" | "tone" | "pov" | "setting" | "memory" | "chapters" | "currentChapterId" | "branchingEnabled" | "branches" | "currentBranchId">;
  characters: Character[];
  messages: Pick<Message, "role" | "kind" | "content">[];
};

export async function streamStory(
  body: StoryRequest,
  onDelta: (text: string) => void,
  signal?: AbortSignal,
): Promise<string> {
  const res = await fetch("/api/story", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal,
  });

  if (!res.ok) {
    let message = `Could not write (${res.status})`;
    try {
      const data = (await res.json()) as { error?: string };
      if (data.error) message = data.error;
    } catch {
      /* ignore */
    }
    throw new Error(message);
  }

  if (!res.body) throw new Error("Empty response");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let full = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split("\n\n");
    buffer = chunks.pop() ?? "";
    for (const chunk of chunks) {
      const line = chunk
        .split("\n")
        .filter((l) => l.startsWith("data:"))
        .map((l) => l.slice(5).trim())
        .join("");
      if (!line || line === "[DONE]") continue;
      let parsed: { delta?: string; error?: string };
      try {
        parsed = JSON.parse(line) as { delta?: string; error?: string };
      } catch {
        continue;
      }
      if (parsed.error) throw new Error(parsed.error);
      if (parsed.delta) {
        full += parsed.delta;
        onDelta(parsed.delta);
      }
    }
  }

  return full;
}

export async function refreshMemory(input: {
  memory: string;
  messages: Pick<Message, "role" | "kind" | "content">[];
}): Promise<string> {
  const res = await fetch("/api/memory", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
  });
  const data = (await res.json()) as { memory?: string; error?: string };
  if (!res.ok || !data.memory) throw new Error(data.error || "Could not update memory");
  return data.memory;
}
