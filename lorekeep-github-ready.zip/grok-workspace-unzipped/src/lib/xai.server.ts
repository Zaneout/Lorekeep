import { MEMORY_SYSTEM, buildStoryMessages } from "@/lib/prompt";
import { allowAiCall } from "@/lib/rate-limit";
import type { Character, Message, Story } from "@/lib/types";

const MAX_BODY = 400_000;

export type StoryBody = {
  story: Pick<Story, "title" | "premise" | "genre" | "tone" | "pov" | "setting" | "memory" | "chapters" | "currentChapterId" | "branchingEnabled" | "branches" | "currentBranchId">;
  characters: Character[];
  messages: Pick<Message, "role" | "kind" | "content">[];
};

function apiKey(): string | null {
  const key = process.env.XAI_API_KEY?.trim();
  return key || null;
}

export function readLimitedJson(text: string): unknown {
  if (text.length > MAX_BODY) {
    throw Object.assign(new Error("That story is too large to send in one pass."), { status: 413 });
  }
  return JSON.parse(text) as unknown;
}

function isStoryBody(value: unknown): value is StoryBody {
  if (!value || typeof value !== "object") return false;
  const v = value as StoryBody;
  return Boolean(v.story) && Array.isArray(v.characters) && Array.isArray(v.messages);
}

export async function streamGrokStory(body: unknown): Promise<Response> {
  const key = apiKey();
  if (!key) {
    return Response.json({ error: "Writing is unavailable in this environment." }, { status: 503 });
  }
  if (!allowAiCall()) {
    return Response.json({ error: "Too many writes just now. Wait a moment." }, { status: 429 });
  }
  if (!isStoryBody(body)) {
    return Response.json({ error: "Invalid story payload." }, { status: 400 });
  }

  const messages = buildStoryMessages(body);
  const upstream = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      stream: true,
      temperature: 0.95,
      max_tokens: 2048,
      reasoning_effort: "low",
      messages,
    }),
  });

  if (!upstream.ok || !upstream.body) {
    const errText = await upstream.text().catch(() => "");
    const status = upstream.status === 401 || upstream.status === 403 ? 503 : 502;
    return Response.json(
      { error: errText.slice(0, 240) || `Writer error ${upstream.status}` },
      { status },
    );
  }

  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const reader = upstream.body.getReader();

  const stream = new ReadableStream({
    async start(controller) {
      let buffer = "";
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const parts = buffer.split("\n");
          buffer = parts.pop() ?? "";
          for (const part of parts) {
            const line = part.trim();
            if (!line.startsWith("data:")) continue;
            const data = line.slice(5).trim();
            if (!data || data === "[DONE]") continue;
            try {
              const json = JSON.parse(data) as {
                choices?: { delta?: { content?: string } }[];
              };
              const delta = json.choices?.[0]?.delta?.content;
              if (delta) {
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta })}\n\n`));
              }
            } catch {
              /* skip malformed chunk */
            }
          }
        }
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ done: true })}\n\n`));
        controller.close();
      } catch (error) {
        const message = error instanceof Error ? error.message : "Stream failed";
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: message })}\n\n`));
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}

export async function summarizeMemory(input: unknown): Promise<Response> {
  const key = apiKey();
  if (!key) {
    return Response.json({ error: "Writing is unavailable in this environment." }, { status: 503 });
  }
  if (!allowAiCall()) {
    return Response.json({ error: "Too many writes just now. Wait a moment." }, { status: 429 });
  }

  const body = input as { memory?: string; messages?: Pick<Message, "role" | "kind" | "content">[] };
  if (!body || !Array.isArray(body.messages)) {
    return Response.json({ error: "Invalid memory payload." }, { status: 400 });
  }

  const transcript = body.messages
    .slice(0, 80)
    .map((m) => {
      const who = m.role === "assistant" ? "Story" : m.kind === "continue" ? "Continue" : "Author";
      return `${who}: ${m.content.slice(0, 4000)}`;
    })
    .join("\n\n");

  const upstream = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      stream: false,
      temperature: 0.3,
      max_tokens: 1200,
      reasoning_effort: "low",
      messages: [
        { role: "system", content: MEMORY_SYSTEM },
        {
          role: "user",
          content: `Existing memory:\n${(body.memory || "None").slice(0, 8000)}\n\nOlder scenes to absorb:\n${transcript.slice(0, 24000)}`,
        },
      ],
    }),
  });

  if (!upstream.ok) {
    return Response.json({ error: `Memory error ${upstream.status}` }, { status: 502 });
  }
  const json = (await upstream.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const memory = json.choices?.[0]?.message?.content?.trim() ?? "";
  if (!memory) return Response.json({ error: "Empty memory." }, { status: 502 });
  return Response.json({ memory });
}
