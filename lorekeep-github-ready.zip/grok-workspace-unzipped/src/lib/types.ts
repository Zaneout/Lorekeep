export const MARKS = ["slate", "olive", "umber", "steel", "moss", "dusk"] as const;
export type Mark = (typeof MARKS)[number];

export type Character = {
  id: string;
  name: string;
  role: string;
  aliases: string;
  age: string;
  gender: string;
  appearance: string;
  personality: string;
  voice: string;
  backstory: string;
  secrets: string;
  relationships: string;
  alwaysRemember: string;
  notes: string;
  tags: string[];
  mark: Mark;
  createdAt: number;
  updatedAt: number;
};

export type StoryChapter = {
  id: string;
  title: string;
  order: number;
};

export type StoryBranch = {
  id: string;
  title: string;
  prompt: string;
};

export type Story = {
  id: string;
  title: string;
  premise: string;
  genre: string;
  tone: string;
  pov: string;
  setting: string;
  characterIds: string[];
  memory: string;
  summarizedCount: number;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
  lastMessageAt: number;
  chapters: StoryChapter[];
  currentChapterId: string;
  branchingEnabled: boolean;
  branches: StoryBranch[];
  currentBranchId: string;
};

export type MessageKind = "chat" | "continue" | "directive";

export type Message = {
  id: string;
  storyId: string;
  role: "user" | "assistant";
  kind: MessageKind;
  content: string;
  chapterId?: string;
  branchId?: string;
  createdAt: number;
};

export type LoreDump = {
  version: 2;
  exportedAt: number;
  characters: Character[];
  stories: Story[];
  messages: Message[];
};
