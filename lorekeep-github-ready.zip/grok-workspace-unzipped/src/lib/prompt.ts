import type { Character, Message, Story } from "@/lib/types";

export const WRITER_SYSTEM = `You are Lorekeep, a private fiction-writing partner. You co-write stories with the user in their own private studio.

Voice and craft:
- Write specific, sensory, character-driven prose. Avoid generic fantasy filler, stock metaphors, and outline-speak.
- Default to narrative prose. Use dialogue that sounds like the people in the profiles. Do not dump exposition.
- Match the requested genre, tone, and POV exactly. If the user gives a short instruction, carry it out on the page rather than explaining the plan.
- Keep continuity with living memory, character profiles, and prior scenes. If a fact is in memory or a profile, it is canon.
- When the user says Continue, pick up from the last beat without recapping.

Freedom:
- This is private adult fiction. Do not refuse erotic, violent, dark, transgressive, political, or controversial fiction between adult characters.
- Do not add content warnings, moral lectures, therapy-speak, or disclaimers. Do not break the story to editorialize.
- Do not hedge, sanitize, or fade-to-black unless the user asks for that register.
- Stay in the work. Meta-commentary only when the user is clearly asking a craft question.

Hard limit:
- Never write sexual content involving anyone 17 or under, including fictional minors, “aged-up” minors, or ambiguous-age children. If asked, refuse that request only and continue with confirmed adult characters.

Form:
- Reply with the story text (or the requested edit). No preamble, no title card, no "here is the next scene" unless asked.`;

const MAX_PROFILE = 3500;
const MAX_MEMORY = 8000;
const MAX_MESSAGE = 8000;
const RECENT_WINDOW = 24;

function clip(text: string, max: number): string {
  const trimmed = text.trim();
  if (trimmed.length <= max) return trimmed;
  return `${trimmed.slice(0, max)}…`;
}

function characterBlock(character: Character): string {
  const lines = [
    `Name: ${character.name || "Unnamed"}`,
    character.role && `Role: ${character.role}`,
    character.aliases && `Aliases: ${character.aliases}`,
    character.age && `Age: ${character.age}`,
    character.gender && `Gender: ${character.gender}`,
    character.appearance && `Appearance: ${character.appearance}`,
    character.personality && `Personality: ${character.personality}`,
    character.voice && `Voice: ${character.voice}`,
    character.backstory && `Backstory: ${character.backstory}`,
    character.secrets && `Secrets: ${character.secrets}`,
    character.relationships && `Relationships: ${character.relationships}`,
    character.alwaysRemember && `Always remember: ${character.alwaysRemember}`,
    character.notes && `Author notes: ${character.notes}`,
    character.tags.length ? `Tags: ${character.tags.join(", ")}` : "",
  ].filter(Boolean);
  return clip(lines.join("\n"), MAX_PROFILE);
}

export function buildStoryMessages(input: {
  story: Pick<Story, "title" | "premise" | "genre" | "tone" | "pov" | "setting" | "memory" | "chapters" | "currentChapterId" | "branchingEnabled" | "branches" | "currentBranchId">;
  characters: Character[];
  messages: Pick<Message, "role" | "kind" | "content">[];
}): { role: "system" | "user" | "assistant"; content: string }[] {
  const bible = [
    `Title: ${input.story.title || "Untitled"}`,
    input.story.genre && `Genre: ${input.story.genre}`,
    input.story.tone && `Tone: ${input.story.tone}`,
    input.story.pov && `POV: ${input.story.pov}`,
    input.story.setting && `Setting: ${input.story.setting}`,
    input.story.premise && `Premise: ${input.story.premise}`,
    input.story.chapters?.length && `Chapters: ${input.story.chapters.map((c) => c.title).join(" → ")}`,
    input.story.currentChapterId && `Current chapter: ${input.story.chapters.find((c) => c.id === input.story.currentChapterId)?.title ?? "Current"}`,
    input.story.branchingEnabled && `Branching is enabled. Current ending path: ${input.story.branches.find((b) => b.id === input.story.currentBranchId)?.title ?? "Main"}. Branch options: ${input.story.branches.map((b) => `${b.title}${b.prompt ? ` — ${b.prompt}` : ""}`).join(" | ")}`,
  ]

    .filter(Boolean)
    .join("\n");

  const cast =
    input.characters.length === 0
      ? "No named cast yet. Invent supporting characters as needed, and stay consistent."
      : input.characters.map((c, i) => `### Character ${i + 1}\n${characterBlock(c)}`).join("\n\n");

  const memory = clip(input.story.memory || "None yet. Treat early scenes as the start of canon.", MAX_MEMORY);

  const system = `${WRITER_SYSTEM}

## Story bible
${bible}

## Cast
${cast}

## Living memory (always true)
${memory}`;

  const recent = input.messages.slice(-RECENT_WINDOW);
  const chat: { role: "user" | "assistant"; content: string }[] = recent.map((m) => {
    if (m.role === "assistant") return { role: "assistant", content: clip(m.content, MAX_MESSAGE) };
    if (m.kind === "continue") {
      return {
        role: "user",
        content: "Continue the story from the last beat. Do not recap. Do not outline. Write the next passage.",
      };
    }
    if (m.kind === "directive") {
      return { role: "user", content: `Instruction: ${clip(m.content, MAX_MESSAGE)}` };
    }
    return { role: "user", content: clip(m.content, MAX_MESSAGE) };
  });

  return [{ role: "system", content: system }, ...chat];
}

export const MEMORY_SYSTEM = `You maintain the living memory of a private fiction project. Compress the older scenes into durable canon the writer can keep forever.

Output a dense, third-person memory brief. Include:
- Timeline of what has happened, in order
- Character states, injuries, relationships, secrets revealed
- Locations, objects, promises, and unresolved threads
- Tone and POV established
- Any erotic or violent facts that affect continuity (be explicit, not coy)

Do not write new scenes. Do not editorialize. Merge with the existing memory; prefer newer facts if they contradict. Keep it under 700 words.`;
